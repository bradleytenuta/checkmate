/**
	JavaSE-8
*/
import org.junit.Test;
import junit.framework.Assert;

public class ExampleUnitTest {
	@Test
	public void exampleTrueTest() {
		Assert.assertEquals(true, true);
	}
	@Test
	public void exampleFalseTest() {
		Assert.assertEquals(true, false);
	}
}