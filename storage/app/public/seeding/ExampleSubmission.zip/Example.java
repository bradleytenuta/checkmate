public class Example {
	
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
	
	public static Boolean exampleTrue() {
		return true;
	}
	public static Boolean exampleFalse() {
		return false;
	}
}