import static org.junit.Assert.assertEquals;
import org.junit.*;

public class ExampleUnitTest2 {
	@Test
	public void exampleFailTest() {
		assertEquals(true, false);
	}
}