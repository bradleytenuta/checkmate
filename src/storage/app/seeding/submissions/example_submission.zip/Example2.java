public class Example2 {
	
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
	
	public static Boolean example2True() {
		return true;
	}
}